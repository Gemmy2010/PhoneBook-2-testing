﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;


namespace PhoneBook2
{
    class Program
    {
        static void Main(string[] args)
        {

            IndividualUser User = new IndividualUser();

            User.PersonalId = "23454";
            User.FirstName = "kim";
            User.LastName = "Peter";
            
            User.Adress = "Stockholm";
            User.PhoneNumber = "073245678";

            AdressBook adress = new AdressBook();

            adress.Add(User);

            //Updating Adressbook
           
            User.PersonalId = "23454";
            User.FirstName = "John";
            User.LastName = "Patrick";

            User.Adress = "Uppdsala";
            User.PhoneNumber = "073245678";

            adress.UpdateUser(User);

            Console.WriteLine(User);
            Console.ReadLine();

        }

    }

}







           