﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace PhoneBook2
{
    public class User
    {
        private Hashtable adressBook = new Hashtable();
        public string personalid;
        public string firstname;
        public string lastname;
        public string adress;
        public string phonenumber;

        public string PersonalId { get; set; }
        

        public string FirstName { get; set; }

       
        public string LastName { get; set; }
        
        public string Adress { get; set; }
        
        public string PhoneNumber { get; set; }

        // constructor
        public User()
        {
            this.PersonalId = null;
            this.FirstName = null;
            this.LastName = null;
            this.Adress = null;
            this.PhoneNumber = null;
        }

        public User(string personalId, string firstName, string lastName, string adress, string phoneNumber)
        {
            this.PersonalId = personalId;
            this.FirstName = firstName;
            this.LastName = lastName;
            this.Adress = adress;
            this.PhoneNumber = phoneNumber;
        }
        public override string ToString()

        {
            return "PersonalId : " + this.PersonalId + "/n " +
                   "FirstName : " + this.FirstName + "/n " +
                   "LastName : " + this.LastName + "/n" +
                   "Adress :" + this.Adress + "/n " +
                   "PhoneNumber :" + this.PhoneNumber + "/n";
        }
    }
    public class IndividualUser : User
    {
        public string BirthDate { get; set; }
        public IndividualUser() : base()
        {
            this.BirthDate = null;
        }

        public override string ToString()
        {
            return base.ToString() + "BirthDate:" + this;
        }

    }
    public class UserEnum : User
    {
        Hashtable adressBook = new Hashtable();
        int personalId = 0;



        //Constructor
        public UserEnum(IEnumerable adressBook)
        {
            adressBook = null;
        }

        // Accessing the next item in the list.

         public object MoveNext
         {
             get
             {
                 personalId += 1;

                 if (IsDone == false)
                 {
                     return adressBook[personalId];
                 }
                 else
                 {
                     return null;
                 }
             }
         }


        // Accessing the current item in the list.

        public object CurrentItem
        {
            get
            {
                return adressBook[personalId];
            }
        }


        // Reaching the end of the list.

        public bool IsDone
        {
            get
            {
                if (personalId < adressBook.Count)
                {
                    return false;
                }
                return true;
            }
        }



    }
}


