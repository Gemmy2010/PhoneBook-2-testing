﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using PhoneBookLib;

namespace Phonebooktests.cs
{
    [TestMethod]
    public void PhoneBookHasNoEntriesAtStart()
    {
        PhoneBook2 phoneBook = new PhoneBook2();
        Assert.AreEqual(0, phoneBook.GetNumberOfEntries(), "No entries to start with.");
    }
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
        

        [TestMethod]
        public void CanAddEntry()
        {
            PhoneBook phoneBook = new PhoneBook();
            phoneBook.Add("Gorkem", "555");
        }

        [TestMethod]
        public void CannotAddNullNamedEntry()
        {
            PhoneBook phoneBook = new PhoneBook();
            Assert.ThrowsException<ArgumentNullException>(() => phoneBook.Add(null, "555"));
        }

        [TestMethod]
        public void AddedEntryMaintainsValue()
        {
            PhoneBook phoneBook = new PhoneBook();
            phoneBook.Add("Gorkem", "555");
            string number = phoneBook.GetNumberFor("Gorkem");
            Assert.AreEqual("555", number, "Saved number is returned correctly.");
        }

    }
}

    } 
}
